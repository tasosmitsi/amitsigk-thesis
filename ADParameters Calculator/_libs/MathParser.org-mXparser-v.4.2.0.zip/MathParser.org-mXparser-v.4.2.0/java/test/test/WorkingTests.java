package test;

import org.mariuszgromada.math.mxparser.*;

public class WorkingTests {

	public static void main(String[] args) {
		mXparser.consolePrintHelp("4.2");
	}

}
